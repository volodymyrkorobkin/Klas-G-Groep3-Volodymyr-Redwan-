<?php
// Redirect to home.php
header("Location: pages/home.php");